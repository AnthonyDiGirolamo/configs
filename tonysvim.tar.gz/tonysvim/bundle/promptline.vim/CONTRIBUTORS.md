[Henrique Ferreiro](https://github.com/hferreiro) - fix tilde expansion in bash 4.3
